-- name: NathyCheats v0.1
-- description: Cheats activated through chat commands made by Nathyng. Use '!nc help' in the chat and enjoy.
-- author: Nathyng

godmode = false
infinite_jump = false
speed_boost = false
fly_mode = false
tiny_mode = false
giant_mode = false

-----------------------------
-- POPUP AL INICIAR NIVEL
-----------------------------
function on_start()
    djui_popup_create("NathyCheats loaded! Use !nathycheats help", 3)
end

hook_event(HOOK_ON_LEVEL_INIT, on_start)

-----------------------------
-- PROCESAR COMANDOS
-----------------------------
function on_chat(m, msg)
    if msg == nil then return false end

    msg = msg:lower()

    if not (msg:find("!nathycheats") or msg:find("!nc")) then
        return false
    end

    local args = {}
    for word in msg:gmatch("%S+") do
        table.insert(args, word)
    end

    local cmd = args[2]

    -- HELP
    if cmd == nil or cmd == "help" then
        djui_chat_message_create("=== NathyCheats v0.1 ===")
        djui_chat_message_create("!nathycheats god     - Toggle God Mode")
		djui_chat_message_create("!nathycheats jump    - Toggle Infinite Jump")
		djui_chat_message_create("!nathycheats speed   - Toggle Speed Boost")
		djui_chat_message_create("!nathycheats fly     - Toggle Fly Mode")
		djui_chat_message_create("!nathycheats tiny    - Small Mario")
		djui_chat_message_create("!nathycheats giant   - Giant Mario")
		djui_chat_message_create("!nathycheats status  - Show all values")
		djui_chat_message_create("!nathycheats reset   - Reset all cheats")
        return true
    end

    -- STATUS
    if cmd == "status" then
        djui_chat_message_create("=== NathyCheats Status ===")
        djui_chat_message_create("God Mode: " .. tostring(godmode))
        djui_chat_message_create("Infinite Jump: " .. tostring(infinite_jump))
        djui_chat_message_create("Speed Boost: " .. tostring(speed_boost))
        djui_chat_message_create("Fly Mode: " .. tostring(fly_mode))
		djui_chat_message_create("Tiny: " .. tostring(tiny_boost))
        djui_chat_message_create("Giant: " .. tostring(giant_mode))
        return true
    end

    -- RESET
    if cmd == "reset" then
        godmode = false
        infinite_jump = false
        speed_boost = false
        fly_mode = false
		tiny_mode = false
		giant_mode = false
        djui_chat_message_create("All cheats have been reset.")
        return true
    end

    -- GOD
    if cmd == "god" then
        godmode = not godmode
        djui_chat_message_create("God Mode: " .. tostring(godmode))
        return true
    end

    -- JUMP
    if cmd == "jump" then
        infinite_jump = not infinite_jump
        djui_chat_message_create("Infinite Jump: " .. tostring(infinite_jump))
        return true
    end

    -- SPEED
    if cmd == "speed" then
        speed_boost = not speed_boost
        djui_chat_message_create("Speed Boost: " .. tostring(speed_boost))
        return true
    end

    -- FLY
    if cmd == "fly" then
        fly_mode = not fly_mode
        if fly_mode then
            djui_chat_message_create("Fly Mode: true")
            djui_chat_message_create("Controls: Stick = move, A = ascend, B = descend")
        else
            djui_chat_message_create("Fly Mode: false")
        end
        return true
    end
	
	-- TINY
if cmd == "tiny" then
    tiny_mode = not tiny_mode
    giant_mode = false

    djui_chat_message_create("Tiny Mode: " .. tostring(tiny_mode))

    return true
end

-- GIANT
if cmd == "giant" then
    giant_mode = not giant_mode
    tiny_mode = false

    djui_chat_message_create("Giant Mode: " .. tostring(giant_mode))

    return true
end

    djui_chat_message_create("Unknown command. Use !nathycheats help")
    return true
end

hook_event(HOOK_ON_CHAT_MESSAGE, on_chat)

-----------------------------
-- APLICAR CHEATS
-----------------------------
function apply_cheats()
    local m = gMarioStates[0]
    if not m then return end

    if godmode then
	m.health = 0x880
    end
	
	-- TINY / GIANT MODE
if tiny_mode then
    -- Escala visual
    m.marioObj.header.gfx.scale.x = 0.4
    m.marioObj.header.gfx.scale.y = 0.4
    m.marioObj.header.gfx.scale.z = 0.4

    -- Hitbox pequeña
    m.marioObj.hitboxRadius = 20
    m.marioObj.hitboxHeight = 40

    -- Ajustar altura del personaje
    m.marioObj.header.gfx.node.flags = m.marioObj.header.gfx.node.flags & ~GRAPH_RENDER_INVISIBLE

elseif giant_mode then
    -- Escala visual
    m.marioObj.header.gfx.scale.x = 2.5
    m.marioObj.header.gfx.scale.y = 2.5
    m.marioObj.header.gfx.scale.z = 2.5

    -- Hitbox gigante
    m.marioObj.hitboxRadius = 120
    m.marioObj.hitboxHeight = 240

    -- Ajustar altura del personaje
    m.marioObj.header.gfx.node.flags = m.marioObj.header.gfx.node.flags & ~GRAPH_RENDER_INVISIBLE

else
    -- Restaurar tamaño normal
    m.marioObj.header.gfx.scale.x = 1
    m.marioObj.header.gfx.scale.y = 1
    m.marioObj.header.gfx.scale.z = 1

    m.marioObj.hitboxRadius = 37
    m.marioObj.hitboxHeight = 160
end

    if infinite_jump then
    if (m.controller.buttonPressed & A_BUTTON) ~= 0 then 
        m.vel.y = 60
    end
end

    if speed_boost then
        if m.forwardVel < 60 then
            m.forwardVel = m.forwardVel + 4
        end
    end

if fly_mode then
    -- Cancelar gravedad
    m.vel.y = 0

    -- Movimiento horizontal rápido
    local speed = 25
    local forward = m.faceAngle.y

    -- Stick para moverse
    local stickX = m.controller.stickX
    local stickY = m.controller.stickY

    if stickX ~= 0 or stickY ~= 0 then
        local angle = atan2s(-stickY, stickX)
        m.pos.x = m.pos.x + sins(angle) * speed * 0.3
        m.pos.z = m.pos.z + coss(angle) * speed * 0.3
    end

    -- A para subir
    if (m.controller.buttonDown & A_BUTTON) ~= 0 then
        m.pos.y = m.pos.y + 5
    end

    -- B para bajar
    if (m.controller.buttonDown & B_BUTTON) ~= 0 then
        m.pos.y = m.pos.y - 5
    end

    -- Evitar animaciones raras
    m.action = ACT_FREEFALL
end

end

hook_event(HOOK_MARIO_UPDATE, apply_cheats)