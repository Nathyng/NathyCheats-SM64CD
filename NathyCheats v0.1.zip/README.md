# NathyCheats v0.1
Cheats activated through chat commands, created by **Nathyng** for **Super Mario 64 Coop Deluxe**.  
Use `!nc help` in the chat to see all available commands.

---

## Features
NathyCheats adds a collection of fun and useful cheats that can be toggled directly from the in‑game chat.  
All cheats work in real time and are fully compatible with Coop Deluxe v1.4.1.

---

## Commands

You can use **either prefix**:

- `!nathycheats`
- `!nc`

Example:  
`!nc god`  
`!nathycheats fly`

### Cheat Commands

| Command | Description |
|--------|-------------|
| `god` | Toggle God Mode (invincible) |
| `jump` | Toggle Infinite Jump (double/triple jump included) |
| `speed` | Toggle Speed Boost |
| `fly` | Toggle Fly Mode (A = ascend, B = descend) |
| `tiny` | Shrink Mario (visual + hitbox) |
| `giant` | Enlarge Mario (visual + hitbox) |
| `status` | Show current cheat states |
| `reset` | Reset all cheats |

---

## Installation
1. Place the mod folder inside your `mods` folder in SM64 Coop Deluxe.
2. Enable the mod in the in‑game Mod Manager.
3. Start any level and type `!nc help` in chat.

---

## Notes
- All cheats work only for the local player.
- Designed for Coop Deluxe v1.4.1.
- More features coming soon.

---

## Author
Created by **Nathyng**  